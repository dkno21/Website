let hargaTerpilih = 0;
let validNick = ""; // Menyimpan nama nickname yg sukses di cek

// --- 1. FITUR GANTI TEMA (LIGHT/DARK) ---
function toggleTheme() {
    const body = document.body;
    const icon = document.getElementById("themeIcon");
    
    // Cek apakah sedang mode dark atau light
    const isLight = body.getAttribute("data-theme") === "light";

    if (isLight) {
        body.setAttribute("data-theme", "dark");
        icon.classList.remove("fa-sun");
        icon.classList.add("fa-moon");
    } else {
        body.setAttribute("data-theme", "light");
        icon.classList.remove("fa-moon");
        icon.classList.add("fa-sun");
    }
}

// --- 2. FITUR CEK NICKNAME (API PUBLIK) ---
async function cekNama() {
    const id = document.getElementById("userId").value;
    const zone = document.getElementById("zoneId").value;
    const btn = document.getElementById("btnCek");
    const resultDisplay = document.getElementById("nickResult");

    if (!id || !zone) {
        alert("Isi User ID dan Zone ID dulu bos!");
        return;
    }

    // Ubah tombol jadi loading
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
    resultDisplay.innerText = "";
    
    try {
        // CONTOH API GRATIS (Bisa diganti jika mati)
        // Format API biasanya: url?id=xxxx&zone=xxxx
        // Di sini saya pakai contoh logic dummy dulu agar tidak error di Vercel
        // KARENA API GRATIS SERING MATI/GANTI URL.
        
        // --- SIMULASI API (Komentari bagian ini jika punya API asli) ---
        await new Promise(r => setTimeout(r, 1000)); // Pura-pura loading 1 detik
        const mockName = "Player_" + Math.floor(Math.random() * 1000); 
        validNick = mockName; // Simpan nama
        resultDisplay.innerText = "✅ Username: " + validNick;
        resultDisplay.style.color = "var(--accent-color)";
        // -----------------------------------------------------------

        /* JIKA PUNYA API ASLI, PAKAI KODE INI:
        const response = await fetch(`https://api.vgc.my.id/v1/check/mlbb?id=${id}&zone=${zone}`);
        const data = await response.json();
        if(data.status === 200 || data.result) {
            validNick = data.result.username; // Sesuaikan dgn respon API
            resultDisplay.innerText = "✅ Username: " + validNick;
        } else {
            resultDisplay.innerText = "❌ ID Tidak Ditemukan";
            resultDisplay.style.color = "red";
        }
        */

    } catch (error) {
        resultDisplay.innerText = "❌ Gagal mengecek ID (API Error)";
        resultDisplay.style.color = "red";
    }

    // Kembalikan tombol
    btn.innerHTML = '<i class="fas fa-search"></i> Cek ID';
}

// --- 3. HARGA & KIRIM WA ---
function setHarga(harga) {
    hargaTerpilih = harga;
}

function kirimKeWA() {
    const nomorAdmin = "6281234567890"; // GANTI NOMOR WA DISINI
    const userId = document.getElementById("userId").value;
    const zoneId = document.getElementById("zoneId").value;
    const produkEl = document.querySelector('input[name="produk"]:checked');
    const metodeEl = document.querySelector('input[name="metode"]:checked');

    if (!userId || !zoneId) { alert("ID Game belum diisi!"); return; }
    if (!produkEl) { alert("Pilih produk dulu!"); return; }
    if (!metodeEl) { alert("Pilih metode pembayaran!"); return; }

    // Jika user belum cek nick, pakai "Belum Dicek"
    const nickName = validNick !== "" ? validNick : "(Belum Dicek)";

    const pesan = `*Halo Admin, Order Topup!*%0A%0A` +
                  `👤 *Nick:* ${nickName}%0A` +
                  `🎮 *ID:* ${userId} (${zoneId})%0A` +
                  `💎 *Item:* ${produkEl.value}%0A` +
                  `💰 *Bayar:* ${hargaTerpilih}%0A` +
                  `💳 *Via:* ${metodeEl.value}%0A%0A` +
                  `Mohon diproses min!`;

    window.open(`https://wa.me/${nomorAdmin}?text=${pesan}`, '_blank');
}
